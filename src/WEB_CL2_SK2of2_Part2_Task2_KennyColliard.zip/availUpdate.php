<?php
session_start();
if (!isset($_SESSION['staffID'])) {
    header("Location: login.php");
    exit;
}

$currentStaffID  = $_SESSION['staffID'];
$currentRoleID   = $_SESSION['roleID'];
$canManageAll    = in_array($currentRoleID, [3, 4], true);

require 'database.php';

// Datos del formulario
$postedStaffID = filter_input(INPUT_POST, 'staffID', FILTER_VALIDATE_INT);
$rosterID      = filter_input(INPUT_POST, 'rosterID', FILTER_VALIDATE_INT);
$available     = isset($_POST['available']) && $_POST['available'] === '1';

if (!$rosterID) {
    header("Location: availability.php");
    exit;
}

// Determinar a quién le estamos cambiando la availability
if ($canManageAll && $postedStaffID) {
    $staffID = $postedStaffID;
} else {
    // Cook/Waiter solo puede tocar su propio registro
    $staffID = $currentStaffID;
}

if ($available) {
    // Insertar / actualizar como disponible
    $sql = "
        INSERT INTO availability (staffID, rosterID)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE rosterID = VALUES(rosterID)
    ";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ii", $staffID, $rosterID);
    $stmt->execute();
    $stmt->close();
} else {
    // Si no está tildado, eliminar cualquier registro → Not available
    $sql = "DELETE FROM availability WHERE staffID = ? AND rosterID = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("ii", $staffID, $rosterID);
    $stmt->execute();
    $stmt->close();
}

// Volver a la pantalla de availability del staff correspondiente
header("Location: availability.php?staffID=" . urlencode($staffID));
exit;
?>
