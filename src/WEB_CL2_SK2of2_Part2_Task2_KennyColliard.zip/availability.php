<?php
session_start();
if (!isset($_SESSION['staffID'])) {
    header("Location: login.php");
    exit;
}

$loggedStaffID = $_SESSION['staffID'];
$loggedRoleID  = $_SESSION['roleID'];
$loggedName    = $_SESSION['name'];

// Solo Supervisores (3) y Managers (4) pueden ver / elegir otros staff
$canViewAll = in_array($loggedRoleID, [3, 4], true);

require 'database.php';

// 🔥 AGREGAR ESTO — FUNCIÓN QUE FALTABA
function roleName(int $id): string {
    return match ($id) {
        1       => 'Cook',
        2       => 'Waiter',
        3       => 'Supervisor',
        4       => 'Manager',
        default => 'Unknown',
    };
}

// 1) Determinar qué staff estamos viendo
$selectedStaffID = null;

if ($canViewAll) {
    // Supervisor/Manager puede pasar staffID por GET
    $selectedStaffID = filter_input(INPUT_GET, 'staffID', FILTER_VALIDATE_INT);
    if (!$selectedStaffID) {
        // Si no vino, por defecto uso el propio
        $selectedStaffID = $loggedStaffID;
    }
} else {
    // Cook/Waiter solo puede gestionar su propia availability
    $selectedStaffID = $loggedStaffID;
}

// 2) Obtener lista de staff para el dropdown (solo para Supervisores/Managers)
$staffOptions = [];
if ($canViewAll) {
    $sql = "SELECT staffID, name FROM staff ORDER BY staffID ASC";
    $result = $connection->query($sql);
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $staffOptions[] = $row;
        }
        $result->free();
    }
} else {
    $staffOptions[] = [
        'staffID' => $loggedStaffID,
        'name'    => $loggedName
    ];
}

// 3) Obtener roleID del staff seleccionado (para filtrar rosters correctos)
$selectedRoleID = null;
if ($selectedStaffID === $loggedStaffID) {
    $selectedRoleID = $loggedRoleID;
} else {
    $sql  = "SELECT roleID FROM staff WHERE staffID = ?";
    $stmt = $connection->prepare($sql);
    $stmt->bind_param("i", $selectedStaffID);
    $stmt->execute();
    $stmt->bind_result($selectedRoleID);
    $stmt->fetch();
    $stmt->close();

    if (!$selectedRoleID) {
        // Staff inválido → volvemos a la availability del logueado
        header("Location: availability.php");
        exit;
    }
}

// Nombre del staff seleccionado (para el título)
$selectedStaffName = '';
foreach ($staffOptions as $opt) {
    if ((int)$opt['staffID'] === (int)$selectedStaffID) {
        $selectedStaffName = $opt['name'];
        break;
    }
}

// 4) Traer rosters que corresponden al roleID del staff seleccionado
//    y ver si YA tiene availability (LEFT JOIN con availability)
$sql = "
    SELECT
        r.rosterID,
        r.dateTimeFrom,
        r.dateTimeTo,
        CASE WHEN a.staffID IS NULL THEN 0 ELSE 1 END AS isAvailable
    FROM roster r
    JOIN rosterRole rr ON r.rosterID = rr.rosterID
    LEFT JOIN availability a
        ON a.rosterID = r.rosterID
       AND a.staffID = ?
    WHERE rr.roleID = ?
    ORDER BY r.dateTimeFrom ASC
";

$stmt = $connection->prepare($sql);
$stmt->bind_param("ii", $selectedStaffID, $selectedRoleID);
$stmt->execute();
$rosterResult = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Availability – Anthony Fastfood FMS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            padding-top: 70px;
            background-color: #f5f5f5;
        }
        .page-card {
            background-color: #ffffff;
            padding: 20px 24px;
            border-radius: 0.5rem;
            box-shadow: 0 0.25rem 0.5rem rgba(0,0,0,0.05);
        }
        footer {
            margin-top: 40px;
            padding: 10px 0;
            border-top: 1px solid #ddd;
            font-size: 0.9rem;
            color: #666;
        }
    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="index2.php">Anthony Fastfood FMS</a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#mainNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="mainNavbar">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php if ($canViewAll): ?>
                    <li class="nav-item"><a class="nav-link" href="index.php">Staff list</a></li>
                    <li class="nav-item"><a class="nav-link" href="create.php">Create staff</a></li>
                <?php endif; ?>
                <li class="nav-item"><a class="nav-link active" href="availability.php">Availability</a></li>
                <li class="nav-item"><a class="nav-link" href="profile.php">My profile</a></li>
            </ul>

            <span class="navbar-text text-light me-3 fw-semibold">
                <?= htmlspecialchars($_SESSION['name']) ?>
                <span class="text-info">– <?= htmlspecialchars(roleName((int)$_SESSION['roleID'])) ?></span>
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">Logout</a>
        </div>
    </div>
</nav>

<main class="container mt-4">
    <div class="page-card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <div>
                <h1 class="h4 mb-0">Availability</h1>
                <small class="text-muted">
                    View and manage availability for rostered shifts.
                </small>
            </div>
        </div>

        <!-- Selector de staff (solo Supervisor/Manager) -->
        <?php if ($canViewAll): ?>
            <form class="row mb-3" method="get" action="availability.php">
                <div class="col-md-6">
                    <label for="staffSelect" class="form-label">Select staff</label>
                    <select id="staffSelect" name="staffID" class="form-select"
                            onchange="this.form.submit()">
                        <?php foreach ($staffOptions as $opt): ?>
                            <option value="<?= htmlspecialchars($opt['staffID']) ?>"
                                <?= ((int)$opt['staffID'] === (int)$selectedStaffID) ? 'selected' : '' ?>>
                                <?= htmlspecialchars($opt['staffID'] . ' - ' . $opt['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </form>
        <?php else: ?>
            <p><strong>Staff:</strong> <?= htmlspecialchars($selectedStaffName ?: $loggedName) ?></p>
        <?php endif; ?>

        <p class="mb-2">
            <strong>Legend:</strong>
            <span class="badge bg-success me-1">Available</span>
            <span class="badge bg-danger me-1">Not available</span>
        </p>

        <div class="table-responsive">
            <table class="table table-striped table-bordered align-middle text-center">
                <thead class="table-dark">
                <tr>
                    <th scope="col">Roster ID</th>
                    <th scope="col">Start</th>
                    <th scope="col">End</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                <?php if ($rosterResult && $rosterResult->num_rows > 0): ?>
                    <?php while ($row = $rosterResult->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['rosterID']) ?></td>
                            <td><?= htmlspecialchars($row['dateTimeFrom']) ?></td>
                            <td><?= htmlspecialchars($row['dateTimeTo']) ?></td>
                            <td>
                                <?php if ((int)$row['isAvailable'] === 1): ?>
                                    <span class="badge bg-success">
                                        ✓ Available
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-danger">
                                        ✕ Not available
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="availability2.php?rosterID=<?= urlencode($row['rosterID']) ?>&staffID=<?= urlencode($selectedStaffID) ?>"
                                   class="btn btn-primary btn-sm">
                                    Confirm / Change
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-muted">No rostered shifts found for this staff.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</main>

<footer class="text-center">
    © Gelos Enterprises – Anthony Fastfood FMS – Student: Kenny Luis Colliard
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
